/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AdventureSimulator;

/**
 *
 * @author Luis Sandoval
 */
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

/*public class UIFramework
{
    public void start(Stage stage)
    {
        TextField Namefld = new TextField();
        TextField Class = new TextField();
        
        //create labels
        Label Name = new Label("Name");
        
        //bind label to according field
        Name.setLabelFor(Namefld);
        Name.setMnemonicParsing(true);
        
        //create grid
        GridPane root = new GridPane();
        
        root.addRow(0, Name,Namefld);
        //set size
        root.setMinSize(350, 250);
        
        root.setStyle("-fx-padding: 10;" +
                "-fx-border-style: solid inside;" +
                "-fx-border-width: 2;" +
                "-fx-border-insets: 5;" +
                "-fx-border-radius: 5;" +
                "-fx-border-color: blue;");
        //create the scene
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.setTitle("Adventure Simulator");
        stage.show();
         
        
        
        
    }
    
}*/